/**
* monitor.h
*
* developed for CMPUT379 Assignment 4
*
* author: Brady Pomerleau  -- bpomerle@ualberta.ca
*
*
*/

#ifndef MONITOR_H
#define MONITOR_H

#define _XOPEN_SOURCE 700
#include "constants.h"

void *start_monitor(void *arg);

#endif
