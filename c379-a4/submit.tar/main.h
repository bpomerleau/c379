/**
* main.h
*
* developed for CMPUT379 Assignment 4 - a4tasks
*
* author: Brady Pomerleau  -- bpomerle@ualberta.ca
*
* main program header
*
*/

#ifndef MAIN_H
#define MAIN_H

#define _XOPEN_SOURCE 700

#include "constants.h"

#endif
